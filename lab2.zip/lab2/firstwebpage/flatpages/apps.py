from django.apps import AppConfig


class FlatpagesConfig(AppConfig):
    name = 'flatpages'
